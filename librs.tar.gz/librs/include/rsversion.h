#define rs_major 3
#define rs_middle 1
#define rs_minor 0

