bliss: A Tool for Computing Automorphism Groups and Canonical Labelings of Graphs

Authors: Tommi Junttila and Petteri Kaski

bliss is an open source tool for computing automorphism groups and canonical forms of graphs. 
It has both a command line user interface as well as C++ and C programming language APIs.

The current version 0.73 of bliss; includes GNU LGPL licensed C++ source code and a C API.
