#!/bin/bash

mkdir /usr/local/bin/cgal-examples/
cp -r Shape_detection /Users/monet/Documents/brew/test/Shape_detection