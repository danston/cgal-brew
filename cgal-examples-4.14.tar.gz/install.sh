#!/bin/bash

mkdir /usr/local/bin/cgal-examples/
cp -r Shape_detection /usr/local/bin/cgal-examples/Shape_detection