#!/bin/bash

cp -r Shape_detection /Users/monet/Documents/brew/test/Shape_detection